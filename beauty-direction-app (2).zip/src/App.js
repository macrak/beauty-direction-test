
// ... (기존 import 유지)
import React, { useState, useEffect } from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";
import { MessageCircle, Upload, Loader } from "lucide-react";

// ... 이하 생략된 전체 코드
