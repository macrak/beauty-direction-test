export const Textarea = (props) => (
  <textarea className='w-full border p-2 rounded' {...props} />
);